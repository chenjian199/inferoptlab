# GLM-5.3-Flash-W8A8 / C500 八卡扫描计划

本计划复用项目现有规约。模型、硬件和软件环境通过引用绑定；请求长度、并发、请求倍率在 WorkloadSpec 中；并行形态和服务调度在 DeploymentSpec 中；执行顺序、组合和预算在 BenchmarkPlan 中。这里的表格是阅读入口，执行器读取 YAML，不解析表格，也不另存一套模型参数。

当前运行模式为 `exploratory`。启动成功、API 响应正确、压测记录完整、精度通过和正式 SLA 达标是不同的状态。行业 SLA 的统计口径、比较符和部分原始附件尚未补齐，因此结果不能自动升级为正式验收。

## 阶段计划表

所有部署先通过 `qualify`，再决定是否压测。00—04 是本次启动验证范围；05—08 复用完全相同部署的资格记录。不要把所有阶段串成无人检查的全量压测。

| 阶段 | 计划文件 | 部署候选 | 场景 | 并发 | 重复 | 进入下一阶段的条件 |
| --- | --- | --- | --- | --- | --- | --- |
| 00 并行初筛 | [00-layout.yaml](00-layout.yaml) | A TP8；B TP8/EP8；C TP4/DP2/EP8；D TP2/DP4/EP8 | 4K→1；16K→2K | 1、16、64 | 1 | 启动配置核对和 API 探测通过，再比较吞吐/延迟 |
| 01 调度对照 | [01-scheduling.yaml](01-scheduling.yaml) | budget 2048/8192；seqs 64/256；图执行；A 基线复用 00 | 同 00 | 1、16、64 | 1 | 初版是 A 的五个变体；00 有结果后可引用其他优胜部署，修改后重新验证 |
| 02 长上下文 | [02-context64k.yaml](02-context64k.yaml) | A，max_model_len=73728 | 65536→1 | 1、16、64 | 1 | 精确输入长度响应通过；压测逐级增加并发 |
| 03 超长上下文 | [03-context128k.yaml](03-context128k.yaml) | A，max_model_len=147456 | 131072→1 | 1、16、64 | 1 | 同 02；失败停止该计划，保留容量边界 |
| 04 缓存 Decode | [04-cache.yaml](04-cache.yaml) | A，prefix caching 开启，DP=1 | 同一数据集 4096→1024 | 1、16、64 | 1 | 逐请求缓存证据满足 100% 命中且未命中=0；否则本协议不可执行 |
| 05 短请求复测 | [05-confirm-short.yaml](05-confirm-short.yaml) | A，后续可引用优胜配方 | 16384→2048 | 1、2、4、8、16、32、64、128 | 3 | 引用通过资格检查的部署；复测前准备冻结请求集 |
| 06 长请求复测 | [06-confirm-long.yaml](06-confirm-long.yaml) | A 长上下文配方 | 65536→1024 | 同 05 | 3 | 同 05 |
| 07 超长请求复测 | [07-confirm-ultralong.yaml](07-confirm-ultralong.yaml) | A 超长上下文配方 | 131072→1024 | 同 05 | 3 | 同 05 |
| 08 流程验证 | [08-pipeline.yaml](08-pipeline.yaml) | A | 128→32 | 1、2 | 1 | 仅验证启动、AIPerf、归档和报告链路，不作为性能基线 |

每个 DP 引擎的序列上限初始为 `128/DP`；全局客户端并发单独定义。调度对照阶段的 64/256 是 DP=1 的对照点。显存比例固定 0.90，chunked prefill 开启。`max_num_batched_tokens` 是调度预算，并非每请求固定 chunk 长度。EP 在上述形态中共享 TP×DP ranks，不额外乘卡数。

资格验证只发少量请求：128 输入/32 输出，以及该计划最大输入长度/1 输出；也会检查配置能容纳完整输入与输出长度。它不证明目标并发的容量，不替代语义精度测试。缓存资格会额外检查同输入填充和重放。

资格复用要求部署、模型、硬件、runtime 的内容哈希相同，已成功探测的输入长度覆盖新场景，且服务回读验证过的 `max_model_len` 能容纳新场景输入与输出总长度。因此 64K→1 的启动证据可以用于同一部署的 64K→1K 计划，但不能用于尚未验证的 128K 输入；复用不代表长输出性能已经测过。

尚不纳入自动执行的项目：PP>1（当前 MetaX GLM 实现未开放）；DP=8（待前四组容量结果）；DP>1 的缓存重放（未验证稳定路由）；MTP、DeepEP、异步调度、自定义 all-reduce、0.92/0.95 显存比例（独立专项验证后才能加入配方）。

原资料的 64K/128K 90% 缓存 P 测试、长上下文全缓存 D 测试保留为后续阶段：需要先验证混合注意力状态缓存以及可实现的命中口径。不能用冷请求数据、普通 API 重放或历史 fakePrefill 数据代替。原表的 48、54 并发点也应在资料对照阶段追加，不改变当前初筛的三点定义。

## 规约分工与唯一参数来源

| 规约 | 本轮位置 | 负责内容 |
| --- | --- | --- |
| ModelSpec | `recipes/models/glm/glm-5.3-flash/cluster-glm53-flash-w8a8.yaml` | 模型结构、精度、权重来源与待补证据 |
| HardwareSpec | 由 Study 的 `hardware_ref` 引用 | 八卡实际分配、序列号、PCI 地址与驱动 |
| RuntimeSpec | `recipes/runtimes/metax60-vllm-glm53-source.yaml` | 固定镜像 ID、源码和库版本、通用启动参数；历史 execution_profile 是观测记录 |
| DeploymentSpec | `recipes/deployments/glm53-flash/c500/vllm/` | TP/PP/DP/EP、实际设备、调度限制、服务地址、模型路径、优化开关 |
| WorkloadSpec | `recipes/workloads/glm53-vllm/` | 输入输出 token 数、种子、并发、倍率和最小请求数、缓存目标 |
| MeasurementProtocol | `recipes/protocols/glm53-vllm/` | P/D/E2E、计时边界、预热、重复、缓存验证 |
| TestCaseSpec | `recipes/test-cases/glm53-vllm/` | 关联模型、workload、协议及 SLA |
| BenchmarkScenario | `recipes/scenarios/glm53-vllm/` | 测试 case 与数据集路径 |
| StudySpec | `recipes/studies/glm53-vllm-c500-scan.yaml` | 资源和软件边界、允许 case、预算 |
| BenchmarkPlan | 本目录 YAML | 引用部署与场景，生成执行矩阵 |

原始行业 SLA 保持不改：16K/2K 为 TTFT 1–3s、TPOT 30ms；64K/1K 为 10–30s、35ms；128K/1K 为 60s、50ms。本轮借用为 Flash 的诊断参考，原始模型名称和未决统计口径保留。1K=1024 是本轮明确选择，不能反向填成原图片的已知事实。

初筛请求数 `N=C×4`。复测使用 `N=C×max(4,ceil(200/C))`，由 workload 的 `count_multiplier` 与 `min_count` 计算。例如 C=16 时 N=208，C=128 时 N=512。协议通过 `warmup_request_count: 4` 和 `warmup_request_multiplier: 1` 声明预热请求数 `max(4,C)`，独立运行且不计入 N；有限请求集包含爬升和排空，结果不冒充持续稳态吞吐。P95/P99 的稳定性仍需更多样本验证。

复测的低并发点成本较高。例如按 128K/1K 的 TTFT 60s、TPOT 50ms 估算，C=1、200 请求仅计时部分约需 6.2 小时。05—07 的每点预算因此设为 12 小时，每个计划总预算 72 小时；这是上限，不是预计耗时。先由初筛实测估算总成本并选定候选，再开始复测。预算不足时保存不完整结果并停止，不减少请求数后宣称满足原计划。

## 执行流程

从项目根目录运行。Linux 控制端需要 `PyYAML`、`jsonschema>=4`、`referencing` 和可用 Docker；镜像、模型和设备来自配方。启动器不下载镜像，不替换占用端口的服务，只停止自己创建且 ownership label 匹配的容器。

```bash
PLAN=recipes/plans/benchmark/glm53-vllm/00-layout.yaml
OUT=experiments/evidence/startup/00-layout

python -m benchmark.load plan "$PLAN"
python -m benchmark.load qualify "$PLAN" --out "$OUT"
```

`qualify` 输出 `qualification.json`、`report.md`、规约快照、每项服务日志、实际配置、设备映射和 API 探测。记录绑定模型、硬件、runtime、deployment 四类规约文档的内容哈希；任何配置变更必须重新验证。这不代表已经计算完整权重的字节哈希，权重完整性仍由 ModelSpec 的证据状态约束。输出目录必须不存在，重试保留第一次记录并换新目录。

如果部分候选失败，通过显式选择生成缩减计划；被排除的候选及原因保留在生成计划中，不静默跳过：

```bash
python -m benchmark.load select "$PLAN" \
  --qualification "$OUT/qualification.json" \
  --out experiments/plans/layout-qualified.yaml
```

准备数据集后再执行；控制端具备 AIPerf 0.12.0 和 tokenizer 环境时，可直接使用现有 CLI：

```bash
python -m benchmark.load prepare experiments/plans/layout-qualified.yaml \
  --tokenizer /path/from/deployment/model
python -m benchmark.load run experiments/plans/layout-qualified.yaml \
  --qualification "$OUT/qualification.json"
```

使用已建立的独立 AIPerf 客户端容器时，`run_scan.py` 会从计划引用的 DeploymentSpec 读取模型挂载和缓存目录，无需再写一套服务参数：

```bash
python tools/deployment/metax-vllm/run_scan.py \
  --client-root "$CLIENT_ROOT" --client-image "$CLIENT_IMAGE" \
  prepare experiments/plans/layout-qualified.yaml
python tools/deployment/metax-vllm/run_scan.py \
  --client-root "$CLIENT_ROOT" --client-image "$CLIENT_IMAGE" \
  run experiments/plans/layout-qualified.yaml \
  --qualification "$OUT/qualification.json"
```

`CLIENT_ROOT` 是包含客户端 `venv/` 的目录，`CLIENT_IMAGE` 必须是创建该 venv 时使用的固定镜像。这是压测客户端环境，不是推理镜像。包装器挂载 Docker socket，以允许已有 adapter 管理自己的测试容器；不在推理镜像中安装 AIPerf。

运行结果归档到 `experiments/runs/benchmark/`，保留解析后的规约快照、资格记录、请求集、真实命令、服务配置、原始 AIPerf 导出、逐请求数据、SLA 判定和报告，并复用现有 experiments 索引。复测使用原始 snapshot 和数据集；不能仅凭相同文件名认为配置未改变。

## 参数依据

- [vLLM 0.32 调度与性能调优](https://docs.vllm.ai/en/v0.32.0/configuration/optimization/)：token 预算和 chunked prefill 的关系。
- [vLLM 0.32 EP 部署](https://docs.vllm.ai/en/v0.32.0/serving/expert_parallel_deployment/)：EP=TP×DP 及 Attention 的分组方式。
- [本轮固定版本的 MetaX GLM 实现](https://github.com/MetaX-MACA/vLLM-metax/blob/0962c8735ffe4795800030680311410848512b82/vllm_metax/models/glm5next/common/model.py)：PP 尚未开放的代码依据。
- [AIPerf 0.12 参数](https://docs.nvidia.com/aiperf/v0.12.0/reference/command-line-options)：客户端并发、请求数、原始结果输出。

网络资料用于确定候选和参数语义；是否可运行以本机记录为准，性能优劣必须通过实际扫描确认。
