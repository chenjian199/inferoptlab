"""Benchmark common module."""
