"""Metric normalization and evaluation."""
