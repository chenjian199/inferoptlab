"""Benchmark load module."""
