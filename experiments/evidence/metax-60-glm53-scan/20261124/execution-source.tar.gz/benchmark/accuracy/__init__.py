"""Benchmark accuracy module."""
